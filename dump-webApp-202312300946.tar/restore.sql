--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "webApp";
--
-- Name: webApp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "webApp" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE "webApp" OWNER TO postgres;

\connect "webApp"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: iscrizione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.iscrizione (
    utente character varying NOT NULL,
    torneo bigint NOT NULL
);


ALTER TABLE public.iscrizione OWNER TO postgres;

--
-- Name: partita; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.partita (
    id bigint NOT NULL,
    giocatore1 character varying,
    giocatore2 character varying,
    torneo bigint NOT NULL,
    data date NOT NULL,
    esito character varying NOT NULL
);


ALTER TABLE public.partita OWNER TO postgres;

--
-- Name: partita_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.partita_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.partita_sequence OWNER TO postgres;

--
-- Name: torneo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.torneo (
    id bigint NOT NULL,
    nome character varying NOT NULL,
    data_inizio date NOT NULL,
    data_fine date NOT NULL,
    luogo character varying NOT NULL,
    stato character varying NOT NULL,
    vincitore character varying,
    numero_partecipanti integer NOT NULL
);


ALTER TABLE public.torneo OWNER TO postgres;

--
-- Name: torneo_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.torneo_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.torneo_sequence OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utente (
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    username character varying NOT NULL,
    password character varying NOT NULL,
    data_nascita date NOT NULL,
    "nazionalità" character varying NOT NULL,
    punteggio integer NOT NULL,
    admin boolean NOT NULL,
    punteggio_settimanale integer NOT NULL
);


ALTER TABLE public.utente OWNER TO postgres;

--
-- Data for Name: iscrizione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.iscrizione (utente, torneo) FROM stdin;
\.
COPY public.iscrizione (utente, torneo) FROM '$$PATH$$/4809.dat';

--
-- Data for Name: partita; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.partita (id, giocatore1, giocatore2, torneo, data, esito) FROM stdin;
\.
COPY public.partita (id, giocatore1, giocatore2, torneo, data, esito) FROM '$$PATH$$/4805.dat';

--
-- Data for Name: torneo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.torneo (id, nome, data_inizio, data_fine, luogo, stato, vincitore, numero_partecipanti) FROM stdin;
\.
COPY public.torneo (id, nome, data_inizio, data_fine, luogo, stato, vincitore, numero_partecipanti) FROM '$$PATH$$/4806.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utente (nome, cognome, username, password, data_nascita, "nazionalità", punteggio, admin, punteggio_settimanale) FROM stdin;
\.
COPY public.utente (nome, cognome, username, password, data_nascita, "nazionalità", punteggio, admin, punteggio_settimanale) FROM '$$PATH$$/4804.dat';

--
-- Name: partita_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.partita_sequence', 3, true);


--
-- Name: torneo_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.torneo_sequence', 11, true);


--
-- Name: iscrizione iscrizione_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iscrizione
    ADD CONSTRAINT iscrizione_pk PRIMARY KEY (utente, torneo);


--
-- Name: partita partita_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partita
    ADD CONSTRAINT partita_pk PRIMARY KEY (id);


--
-- Name: torneo torneo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.torneo
    ADD CONSTRAINT torneo_pk PRIMARY KEY (id);


--
-- Name: utente utente_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pk PRIMARY KEY (username);


--
-- Name: iscrizione iscrizione_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iscrizione
    ADD CONSTRAINT iscrizione_fk FOREIGN KEY (utente) REFERENCES public.utente(username);


--
-- Name: iscrizione iscrizione_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.iscrizione
    ADD CONSTRAINT iscrizione_fk_1 FOREIGN KEY (torneo) REFERENCES public.torneo(id);


--
-- Name: partita partita_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partita
    ADD CONSTRAINT partita_fk FOREIGN KEY (giocatore1) REFERENCES public.utente(username);


--
-- Name: partita partita_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partita
    ADD CONSTRAINT partita_fk_1 FOREIGN KEY (giocatore2) REFERENCES public.utente(username);


--
-- Name: partita partita_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.partita
    ADD CONSTRAINT partita_fk_2 FOREIGN KEY (torneo) REFERENCES public.torneo(id);


--
-- Name: torneo torneo_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.torneo
    ADD CONSTRAINT torneo_fk FOREIGN KEY (vincitore) REFERENCES public.utente(username);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

